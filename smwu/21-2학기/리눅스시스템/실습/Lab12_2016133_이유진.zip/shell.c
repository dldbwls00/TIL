//컴퓨터과학과 2016133 이유진
#include <stdio.h>
#define MAXLEN = 10

int main(int argc, char *argv[]){


	return 0;
}
