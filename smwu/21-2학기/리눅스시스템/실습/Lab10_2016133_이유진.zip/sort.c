//컴퓨터과학과 2016133 이유진
#include <stdio.h>
#include <string.h>
#include "copy.h"

char line[MAXLINE][MAXLINE];
char longest[MAXLINE][MAXLINE];

int main(){
	int len, max = 0, i = 0, j = 0, temp = 0, linenumber;
	while (gets(line[i]) != NULL)
		i++;
	linenumber = i;

	for (i = 0; i < MAXLINE; i++){
		for (j = 0; j < MAXLINE; j++){
			len = strlen(line[j]);
			if (len > max){
				max = len;
				copy(line[j], longest[i]);
				temp = j;
			}
		}
		line[temp][0] = '\0';
		max = 0;
	}
	printf("-----정렬 완료----- \n");
	for (i = 0; i < linenumber; i++)
		printf("%s\n", longest[i]);
	return 0;
}
