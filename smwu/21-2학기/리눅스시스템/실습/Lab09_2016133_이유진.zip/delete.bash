#!/bin/bash
# 001 분반 컴퓨터과학전공 2016133 이유진

ans=no

if [ $# -eq 0 ] #명령줄 인수의 개수가 0이면
then
	route=${PWD##*/} #현재 디렉터리를 대상으로 함
	echo -n "디렉터리 $route을(를) 삭제하시겠습니까? (yes/no): "
	read ans
	route=$PWD
else
	route=$1 #첫번째 명령줄 인수를 받음
	ans=yes
fi

if [ $ans == "no" ]
then exit
fi 

ls $route > now #경로 내의 ls결과를 임시로 파일에 담음
echo `ls $route | wc -w`
let i=1
while (( $i <= `ls $route | wc -w` ))
do
	filename=`sed -n "$i"p < now` #경로 내의 모든 파일,디렉토리 하나씩 불러오기

	if [ -d $filename ] && [ -z "`find $filename -type f`" ] #빈 디렉터리인 경우
	then
		echo -n "디렉터리 $filename을(를) 삭제하시겠습니까? (yes/no) : "
		read ans
		if [ $ans == "yes" ]
		then
			rmdir $filename
		fi

	elif [ -f $filename ] && [ $filename == now ] #임시파일
	then
		continue

	else #파일인 경우 (임시파일 제외)
		echo -n "$filename을(를) 삭제하시겠습니까? (yes/no) : "
		read ans
		if [ $ans == "yes" ]
		then
			rm $filename
		fi
	fi

	let i++
done
rm now #임시파일 삭제
