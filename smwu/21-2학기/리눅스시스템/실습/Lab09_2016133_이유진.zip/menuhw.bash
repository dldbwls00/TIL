#!/bin/bash
# 001분반 컴퓨터과학전공 2016133 이유진

echo -----------------------------------------------------
echo 나의 명령어 메뉴에 오신 것을 환영합니다!
echo -----------------------------------------------------
echo 1. 파일 리스트.
echo 2. 파일 삭제.
echo 3. 에디터 시작 .
echo 4. 파일 내용 보기.
echo 5. 종료.

while true
do
	echo -----------------------------------------------------
	echo -n 메뉴 번호 입력: 
	read menu

	if (( $menu == 1 ))
	then
		echo -n 리스트할 디렉터리 입력: 
		read directory
		if [ -d $directory ]
		then
			echo -----------------------------------------------------
			echo $directory
			echo -----------------------------------------------------
			ls -asl $directory
			continue
		else
			echo 디렉터리가 아님
			continue
		fi

	elif (( $menu == 2 ))
	then
		echo -n 삭제할 파일 이름 입력: 
		read filename
		echo -----------------------------------------------------
		if [ -e $filename ]
		then
			if [ -d $filename ]
			then
				echo -n $filename : 디렉터리입니다. 삭제 불가.
				echo
				continue
			else
				rm $filename
				echo -n $filename 삭제 완료
				echo
				continue
			fi
		else
			echo 존재하지 않는 파일입니다.
			continue
		fi

	elif (( $menu == 3 ))
	then
		echo -n 편집할 파일 이름 입력: 
		read filename
		gedit $filename
		continue

	elif (( $menu == 4 ))
	then
		echo -n 파일 이름 입력: 
		read filename
		echo -----------------------------------------------------
		if [ -e $filename ]
		then
			if [ -d $filename ]
			then
				echo -n $filename : 디렉터리입니다.
				echo
				continue
			else
				more $filename
				continue
			fi
		else
			echo 해당 파일 없음
			continue
		fi
		continue

	elif (( $menu == 5 ))
	then
		break

	else
		echo 잘못된 선택
		continue
	fi
done
