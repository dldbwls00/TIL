//컴퓨터과학과 2016133 이유진
#include <stdio.h>

int main(int argc, char *argv[]){
	FILE *fp;
	int c;
	int i = 1;
	for (i=1; i<=argc; i++){
		if (argc < 2)	fp = stdin; //명령줄 인수가 없는 경우 표준입력 사용
		else{
			if (i == argc) break; //명령줄 인수가 끝난 경우	
			fp = fopen(argv[i], "r"); //읽기 전용으로 파일 열기
			if (fp  == NULL){ //파일이 존재하지 않는 경우
				printf("파일 열기 오류 %s\n", argv[i]);
				return -1;
			}	
		}	
		c = getc(fp);
		while (c != EOF){ //파일 끝이 아니면
			putc(c, stdout); //읽은 문자를 표준출력에 출력
			c = getc(fp); //파일로부터 문자 읽기
		}
	}
	fclose(fp);
	return 0;
}
