//컴퓨터과학과 2016133 이유진
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	FILE *fp;
	int c;
	int i = 1;
	int line = 1;

	if (argc == 1){ //실행 파일만 입력했을 경우
			printf("사용법:	./catn -n [파일이름]\n");
			return -1;
	}
	
	for (i=2; i<=argc; i++){ //명령줄인수로 받아온 파일 개수만큼
		if ((argc == 2) && (strcmp(argv[1],"-n") == 0))	fp = stdin; //파일을 지정하지 않은 경우 표준입력 사용
		else if ((strcmp(argv[1],"-n") != 0)){ //-n이 아닌 다른 옵션을 준 경우
			printf("-n을 사용하세요.\n");
			return -1;
		}
		else{
			if (i == argc)	break; //명령줄 인수가 끝난 경우
			fp = fopen(argv[i], "r"); //읽기 전용으로 파일 열기
			if (fp  == NULL){ //파일이 존재하지 않는 경우(파일이 제대로 열렸는지 검사)
				printf("파일 열기 오류 %s\n", argv[i]);
				return -1;
			}
		}	
		c = getc(fp); //파일로부터 문자 읽기
		printf("  %d ", line); //줄번호 입력
		line++;
		printf("%c" ,c);
		while (c != EOF){ //파일 끝이 아니면
			c = getc(fp); //파일로부터 문자 읽기
			if (c == '\n' && fp == stdin){
				printf("  %d %c", line, c); //줄번호 입력
				line++;
			}
			printf("%c", c);
			if (c == '\n' && fp != stdin){
				printf("  %d ", line); //줄번호 입력
				line++;
			}
		}
		printf("\b\b\b\b\b");
		line--;
	}
	fclose(fp);
	return 0;
}
