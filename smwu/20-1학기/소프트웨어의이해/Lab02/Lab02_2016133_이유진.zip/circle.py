import math

r=float(input("원의 반지름을 입력하세요: "))
area= math.pi*math.pow(r,2)
cir= math.pi*r*2
print("원의 면적:", area)
print("원의 둘레:", cir)
