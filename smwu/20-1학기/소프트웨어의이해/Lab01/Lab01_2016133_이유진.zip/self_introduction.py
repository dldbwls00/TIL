major=input("전공을 입력해주세요 : ")
num=int(input("학번을 입력해주세요 : "))
name=input("이름을 입력해주세요 : ")
print("저는 숙명여대", major, "학부", num, "학번", name, "입니다.")
